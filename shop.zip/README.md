# 1.변경사항
 - 2022-06-26 branch 
    - 스프링부트 2.7.1 버전으로 업데이트
    - querydsl 5.0.0 버전으로 pom.xml 업데이트 및 ItemRepositoryCustomImpl의 fetchResults() deprecated 대응
      (list 조회 및 count 조회 쿼리 분리)
    - WebSecurityConfigurerAdapter deprecated로 인한 SecurityConfig 파일 수정
    - thymeleaf-layout-dialect 3.1.0 버전으로 업데이트
    - modelmapper 3.1.0 버전으로 업데이트